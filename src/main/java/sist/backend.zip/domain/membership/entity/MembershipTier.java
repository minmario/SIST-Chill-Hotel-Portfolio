package sist.backend.domain.membership.entity;

public enum MembershipTier {
    BASIC, PREMIUM, VIP
}
