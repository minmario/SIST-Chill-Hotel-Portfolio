package sist.backend.domain.admin.entity.enums;

public enum RoomStatus {
    AVAILABLE, OCCUPIED, MAINTENANCE
}
