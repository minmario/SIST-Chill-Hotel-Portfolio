package sist.backend.domain.admin.entity.enums;

public enum UserStatus {
    ACTIVE, INACTIVE, BLOCKED
}
