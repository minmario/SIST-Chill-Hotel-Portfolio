package sist.backend.domain.membership.entity;

public enum MembershipTier {
    BRONZE, SILVER, GOLD, VIP
}
