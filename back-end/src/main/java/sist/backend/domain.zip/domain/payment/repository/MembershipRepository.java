package sist.backend.domain.payment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import sist.backend.domain.membership.entity.Membership;

public interface MembershipRepository extends JpaRepository<Membership, Long> {

    // 포인트 기준 만족하는 등급 중 가장 높은 순으로 정렬
    @Query("SELECT m FROM Membership m WHERE m.requiredPoint <= :point ORDER BY m.requiredPoint DESC")
    List<Membership> findTierByPoint(int point);
}
