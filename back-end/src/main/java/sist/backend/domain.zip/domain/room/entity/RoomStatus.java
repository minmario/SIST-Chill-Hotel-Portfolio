package sist.backend.domain.room.entity;

public enum RoomStatus {
    AVAILABLE, OCCUPIED, MAINTENANCE
}
