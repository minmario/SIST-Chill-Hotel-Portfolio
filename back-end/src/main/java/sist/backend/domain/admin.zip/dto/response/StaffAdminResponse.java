package sist.backend.domain.admin.dto.response;

import lombok.*;
import sist.backend.domain.user.entity.User;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StaffAdminResponse {
    private Long userIdx;
    private String id;
    private String name;
    private String email;
    private String phone;

    public static StaffAdminResponse from(User user) {
        return StaffAdminResponse.builder()
                .userIdx(user.getUserIdx())
                .id(user.getId())
                .name(user.getName())
                .email(user.getEmail())
                .phone(user.getPhone())
                .build();
    }
}