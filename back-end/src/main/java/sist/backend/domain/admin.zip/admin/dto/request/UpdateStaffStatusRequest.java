package sist.backend.domain.admin.dto.request;

import lombok.Getter;

@Getter
public class UpdateStaffStatusRequest {
    private String status;
}
