package sist.backend.domain.auth.dto.request;

public class LoginRequest {

}
