package sist.backend.domain.membership.entity;

public enum DiscountType {
    ROOM, DINING, STORE
}
