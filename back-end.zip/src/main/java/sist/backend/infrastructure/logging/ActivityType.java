package sist.backend.infrastructure.logging;

public enum ActivityType {
    HOTEL_RESERVATION, PASSWORD_CHANGE, PAYMENT, DINING_RESERVATION, PAYMENT_CANCEL, ACCOUNT_DELETE, LOGIN, LOGOUT
}
