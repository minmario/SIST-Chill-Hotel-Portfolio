package sist.backend.domain.reservation.entity;

public enum ReservationStatus {
    CONFIRMED, CANCELLED, COMPLETED
}
