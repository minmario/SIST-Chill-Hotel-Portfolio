package sist.backend.domain.user.entity;

public enum UserRole {
    USER, STAFF, ADMIN
}
