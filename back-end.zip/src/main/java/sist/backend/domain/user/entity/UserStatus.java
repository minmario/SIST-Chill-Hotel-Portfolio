package sist.backend.domain.user.entity;

public enum UserStatus {
    ACTIVE, INACTIVE, BLOCKED
}
