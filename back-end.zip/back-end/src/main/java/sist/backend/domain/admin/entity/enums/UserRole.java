package sist.backend.domain.admin.entity.enums;

public enum UserRole {
    user, staff, admin
}
