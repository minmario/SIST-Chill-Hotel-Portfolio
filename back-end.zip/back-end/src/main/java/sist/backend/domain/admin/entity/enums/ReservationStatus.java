package sist.backend.domain.admin.entity.enums;

public enum ReservationStatus {
    CONFIRMED, CANCELLED, COMPLETED
}
