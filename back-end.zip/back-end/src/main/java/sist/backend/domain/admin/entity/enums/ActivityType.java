package sist.backend.domain.admin.entity.enums;

public enum ActivityType {
    hotel_reservation, password_change, payment, dining_reservation, payment_cancel, account_delete, login, logout
}
