package sist.backend.domain.shop.entity;

public enum OrderStatus {
    PENDING, PAID, DELIVERED, CANCELLED
}
